<?php

require __DIR__ . "/../app.php";
